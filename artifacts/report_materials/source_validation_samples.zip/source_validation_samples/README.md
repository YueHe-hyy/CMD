# CMD 源域验证样本材料

本材料用于报告中的定性分析，样本来自 CMD 官方验证集，不包含目标域测试标签。

## 样本清单

| 目标类型 | 序列/帧号 | 距离 | 目标点数 | Ouster 第46轮预测索引 | Hesai 第46轮预测索引 |
|---|---:|---:|---:|---:|---:|
| Pedestrian (`Ped_adult`) | `seq38/0001` | 34.6 m | 152 | 1601 | 3601 |
| Pedestrian (`Ped_adult`) | `seq38/0038` | 30.5 m | 135 | 1638 | 3638 |
| Truck | `seq08/0197` | 51.4 m | 1794 | 597 | 2597 |
| Truck | `seq07/0085` | 51.3 m | 1230 | 285 | 2285 |

距离按标注框中心的水平距离 `sqrt(x^2 + y^2)` 计算。目标点数取自官方 JSON 标注中的 `pointsNum`。

## 目录内容

- `samples/seqXX/FFFF/ouster.npy`：128线机械式激光雷达点云。
- `samples/seqXX/FFFF/hesai.npy`：32线机械式激光雷达点云。
- `samples/seqXX/FFFF/label.json`：该帧原始标注，未经裁剪或改名。
- `calib_to_ego/`：Ouster、Hesai 到 ego 坐标系的原始标定矩阵。
- `epoch46_selected_predictions.json`：从第46轮验证结果中抽取的对应 Ouster/Hesai 预测框、类别和置信度。

## 第46轮完整预测来源

`artifacts/cmd_competition_20261115/training_output/xmu_da_models/centerpoint_source_mix/source_mix_fp32_1gpu/eval/eval_with_train/epoch_46/val/result.pkl`

完整验证预测共 4000 帧：前 2000 帧为 Ouster，后 2000 帧为 Hesai；两部分内部均按 `ImageSets/val.txt` 的序列顺序和帧号 `0000-0199` 排列。

## 实验对照说明

仓库中 `smoke_test`、`smoke_fp32`、`source_mix_sparse` 等日志属于功能验证或未完成试跑，并非在相同训练轮数、相同验证划分下完成的正式消融实验，不能据此量化稀疏化带来的 AP 改善。当前能够可靠用于报告的正式结果是 `source_mix_fp32_1gpu` 第46轮及其后续轮次。
